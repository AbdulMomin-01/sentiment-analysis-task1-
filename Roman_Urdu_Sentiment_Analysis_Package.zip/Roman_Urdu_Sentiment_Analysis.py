# Reproducible Roman Urdu sentiment analysis script
# Place Roman Urdu DataSet.csv in the same folder.


import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import FeatureUnion, Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import (accuracy_score, precision_recall_fscore_support,
                             classification_report, confusion_matrix)

# 1. Load data. The uploaded file has no header row; columns 0 and 1 are review and label.
DATA_PATH = "Roman Urdu DataSet.csv"
raw = pd.read_csv(DATA_PATH, header=None, keep_default_na=False, dtype=str)
df = pd.DataFrame({
    "review": raw.iloc[:, 0].astype(str),
    "sentiment_original": raw.iloc[:, 1].astype(str),
    "extra_metadata": raw.iloc[:, 2].astype(str) if raw.shape[1] > 2 else ""
})
df["review"] = df["review"].str.strip()
df["sentiment_original"] = df["sentiment_original"].str.strip()
df["sentiment"] = df["sentiment_original"].replace({"Neative": "Negative"})

# 2. Normalize text while retaining original text for output.
df["review_clean"] = (
    df["review"].str.lower()
      .str.replace(r"http\S+|www\.\S+", " ", regex=True)
      .str.replace(r"@\w+", " ", regex=True)
      .str.replace("#", " ", regex=False)
      .str.replace(r"[^a-z0-9\s]", " ", regex=True)
      .str.replace(r"\s+", " ", regex=True).str.strip()
)
valid_labels = {"Positive", "Negative", "Neutral"}
df["usable"] = df["sentiment"].isin(valid_labels) & df["review_clean"].ne("")
usable = df[df["usable"]].copy()
unique = usable.drop_duplicates(subset=["review_clean"], keep="first").copy()

# 3. Stratified split after removing exact duplicate review text.
X_train, X_test, y_train, y_test = train_test_split(
    unique["review_clean"], unique["sentiment"],
    test_size=0.20, random_state=42, stratify=unique["sentiment"]
)

def combined_features():
    return FeatureUnion([
        ("word", TfidfVectorizer(ngram_range=(1, 2), min_df=2,
                                 max_features=120000, sublinear_tf=True)),
        ("char", TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5),
                                 min_df=2, max_features=150000, sublinear_tf=True))
    ])

models = {
    "Logistic Regression": Pipeline([
        ("features", combined_features()),
        ("classifier", LogisticRegression(max_iter=1200, class_weight="balanced", C=2.0))
    ]),
    "Linear SVM": Pipeline([
        ("features", combined_features()),
        ("classifier", LinearSVC(class_weight="balanced", C=1.0))
    ]),
    "Multinomial Naive Bayes": Pipeline([
        ("features", TfidfVectorizer(ngram_range=(1, 2), min_df=2,
                                    max_features=120000, sublinear_tf=True)),
        ("classifier", MultinomialNB(alpha=0.5))
    ])
}

# 4. Train and evaluate.
results, predictions = {}, {}
for name, model in models.items():
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    predictions[name] = pred
    mp, mr, mf1, _ = precision_recall_fscore_support(
        y_test, pred, average="macro", zero_division=0
    )
    wp, wr, wf1, _ = precision_recall_fscore_support(
        y_test, pred, average="weighted", zero_division=0
    )
    results[name] = {
        "Accuracy": accuracy_score(y_test, pred),
        "Macro Precision": mp, "Macro Recall": mr,
        "Macro F1": mf1, "Weighted F1": wf1
    }

comparison = pd.DataFrame(results).T.sort_values("Macro F1", ascending=False)
print(comparison)
best_name = comparison.index[0]
best_pred = predictions[best_name]
print("\nBest model:", best_name)
print(classification_report(y_test, best_pred, zero_division=0))

# 5. Confusion matrix.
labels = ["Negative", "Neutral", "Positive"]
cm = confusion_matrix(y_test, best_pred, labels=labels)
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=labels, yticklabels=labels)
plt.xlabel("Predicted"); plt.ylabel("Actual")
plt.title(f"Confusion Matrix - {best_name}")
plt.tight_layout(); plt.show()

# 6. Fit final Logistic Regression on all unique labeled reviews and score every eligible row.
final_model = Pipeline([
    ("features", combined_features()),
    ("classifier", LogisticRegression(max_iter=1200, class_weight="balanced", C=2.0))
])
final_model.fit(unique["review_clean"], unique["sentiment"])
df["predicted_sentiment"] = "Not scored"
df["prediction_confidence"] = np.nan
mask = df["usable"]
df.loc[mask, "predicted_sentiment"] = final_model.predict(df.loc[mask, "review_clean"])
df.loc[mask, "prediction_confidence"] = final_model.predict_proba(
    df.loc[mask, "review_clean"]
).max(axis=1)

# 7. Export all predictions and model comparison.
output = df[["review", "sentiment_original", "sentiment",
             "predicted_sentiment", "prediction_confidence",
             "extra_metadata", "usable"]].copy()
output.columns = ["Review", "Original label", "Corrected label",
                  "Predicted sentiment", "Confidence",
                  "Extra CSV field", "Included in scoring"]
output.to_excel("Sentiment_Analysis_Predictions.xlsx", index=False)
comparison.to_excel("Model_Comparison.xlsx")
print("Saved: Sentiment_Analysis_Predictions.xlsx and Model_Comparison.xlsx")
